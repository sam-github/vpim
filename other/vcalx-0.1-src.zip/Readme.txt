*********
vcalx 0.1
*********

vcalx allows you to connect to an IMAP enabled Exchange server to retrieve you calendar entries and export them to a .ics
file. This file can be then imported into Sunbird or iCal.
As I don't have a Mac, I use Sunbird, but I don't recommand to import the file, since duplicates will be either ignored or will appear many times if you import them. I suggest to create a special calendar for this, and set your export file to this calendar file.

Thanks to Pete for his original idea: http://rasterweb.net/raster/200409.html#09102004110000



======
Notes:
======

Theoretically vcalx supports IMAP with SSL. Though there seems to be a problem with our certificate at work and I can't import it to my keystore, so I get an exception telling "No trusted certificate found". I currently don't have too much time to take care of this, so some help would be appreciated.



======
Usage:
======

Adjust vcalx.properties to your settings. You can set your password there, but I must admit I'm a bit paranoid, so I don't do that and prefer to type it as an argument.

If your password is set in vcalx.properties, start the extraction like this:
java -jar vcalx.jar

Otherwise like this:
java -jar vcalx.jar <your password>



=============
Requirements:
=============
vcalx needs Javamail and JAF (JavaBeans Activation Framework). vcalx.jar already contains the necessary class files, which I added using an ant script and Javamail 1.3.2 and JAF 1.0.2. If you wish to play with the source code, you'll have to download these APIs:
Javamail -> http://java.sun.com/products/javamail/
JAF -> http://java.sun.com/products/javabeans/jaf/




Feel free to contribute and contact me: masterludo[AT]gmx.net
If you wish to donate :) send me an e-mail
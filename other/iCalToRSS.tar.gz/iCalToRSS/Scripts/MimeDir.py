#!/usr/bin/python

import os
import re
import sys

def Unescape(string):
	'''Unescape C style escape codes. Yes this function is probably in the Python library somewhere but it was quicker to re-write it than find it.'''
	theString = ''
	theIterator = iter(string)
	try:
		for C in theIterator:
			if C == '\\':
				C = theIterator.next()
				if C in 'abcdefghijklmnopqrstuvwxyz':
					theString += chr(ord(C) - ord('a'))
				else:
					theString += C
			else:
				theString += C
	except StopIteration:
		pass
	except:
		raise
	return theString
	
class Node(object):
	def __init__(self):
		super(Node, self).__init__()
		self.name = None
		self.attributes = {}
		self.children = []
		self._value = None

	def childrenByName(self, name):
		return filter(lambda X:X.name == name, self.children)

	def childByName(self, name):
		theChildren = filter(lambda X:X.name == name, self.children)
		if len(theChildren) == 0:
			return None
		elif len(theChildren) == 1:
			return theChildren[0]
		else:
			raise Exception('More than 1 children')

	def pprint(self, depth = 0):
		print '%sName: \'%s\'' % ('\t' * depth, self.name)
		if self.value:
			print '%sValue: \'%s\'' % ('\t' * depth, self.value)
		else:
			print '%sChildren:' % ('\t' * depth)
			for theChild in self.children:
				theChild.pprint(depth+1)

	def getValue(self):
		return self._value
	def setValue(self, value):
		self._value = Unescape(value)
	value = property(getValue, setValue)

class MimeDirReader(object):
	def __init__(self):
		super(MimeDirReader, self).__init__()
	def read(self, iterator):
		theNode = Node()
		theNodeStack = [theNode]
		self.lastNode = None
		for theLine in iterator:
			self.processLine(theLine, theNodeStack)
		return theNode.children[0]
	def processLine(self, line, nodeStack):
		line = line.rstrip('\r\n')

		theMatch = re.split('^([^ ].*?):(.+)', line)
		if len(theMatch) > 1:
			theKey = theMatch[1]
			theValue = theMatch[2]

			theAttributes = {}
			theMatch = re.split('(.+?);(.+)', theKey)
			if len(theMatch) > 2:
				theKey = theMatch[1]
				theRawAttributes = theMatch[2]
				theMatch = re.split('(.+?)=(.+)', theRawAttributes)
				theAttributeKey = theMatch[1]
				theAttributeValue = theMatch[2]
				theAttributes[theAttributeKey] = theAttributeValue

			if theKey == 'BEGIN':
# 				print '%sBEGIN' % ('\t' * (len(nodeStack) - 1))
				theNode = Node()
				nodeStack[-1].children.append(theNode)
				theNode.name = theValue
				theNode.attributes = theAttributes
				nodeStack.append(theNode)
				self.lastNode = None
			elif theKey == 'END':
				del(nodeStack[-1])
# 				print '%sEND' % ('\t' * (len(nodeStack) - 1))
				self.lastNode = None
			else:
# 				print '%sDATA' % ('\t' * (len(nodeStack) - 1))
				theNode = Node()
				nodeStack[-1].children.append(theNode)
				theNode.name = theKey
				theNode.attributes = theAttributes
				theNode.value = theValue
				self.lastNode = theNode
		elif line[0] == ' ':
			self.lastNode.value += Unescape(line[1:])

if __name__ == '__main__':
	print 'START'
	theFile = file(os.path.expanduser('~/Desktop/usa_soccer.ics'))
	theIterator = iter(theFile)
	theReader = MimeDirReader()
	theNode = theReader.read(theIterator)
	print 'FINISH'	
	theNode.pprint()

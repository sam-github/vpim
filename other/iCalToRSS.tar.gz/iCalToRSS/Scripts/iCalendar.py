#!/usr/bin/python

import datetime
import os
import urllib2
from pprint import pprint

import MimeDir
import pytz

def stringToDateTime(T, tzinfo = None):
	theObject = None
	theYear = 0
	theMonth = 0
	theDay = 0
	theHour = 0
	theMinute = 0
	theSecond = 0
	theMicroseconds = 0
	if len(T) >= 8:
		theYear = int(T[0:4])
		theMonth = int(T[4:6])
		theDay = int(T[6:8])
		if len(T) >= 16:
			theHour = int(T[9:11])
			theMinute = int(T[11:13])
			theSecond = int(T[13:15])
			theObject = datetime.datetime(theYear, theMonth, theDay, theHour, theMinute, theSecond, theMicroseconds, tzinfo)
		else:
			theObject = datetime.date(theYear, theMonth, theDay)
	return theObject

class CalendarItem(object):
	def __init__(self):
		super(CalendarItem, self).__init__()
		self.completed = None
		self.description = ''
		self.due = None
		self.priority = None
		self.startDateTime = None
		self.summary = ''
		self.timestamp = None
		self.uid = None
		self.url = None

	def setWithMimeDirNode(self, node):
		if node.childByName('COMPLETED') != None:
			self.completed = stringToDateTime(node.childByName('COMPLETED').value)
		if node.childByName('DESCRIPTION') != None:
			self.description = node.childByName('DESCRIPTION').value
		if node.childByName('DUE') != None:
			self.due = stringToDateTime(node.childByName('DUE').value)
		if node.childByName('PRIORITY') != None:
			self.priority = int(node.childByName('PRIORITY').value)
		if node.childByName('DTSTART') != None:
			theTimeZone = None
			if node.childByName('DTSTART').attributes.has_key('TZID'):
				theTimeZoneName = node.childByName('DTSTART').attributes['TZID']
				theTimeZone = pytz.timezone(theTimeZoneName)
			self.startDateTime = stringToDateTime(node.childByName('DTSTART').value, theTimeZone)
		if node.childByName('SUMMARY') != None:
			self.summary = node.childByName('SUMMARY').value
		if node.childByName('DTSTAMP') != None:
			self.timestamp = stringToDateTime(node.childByName('DTSTAMP').value)
		if node.childByName('UID') != None:
			self.uid = node.childByName('UID').value
		if node.childByName('URL') != None:
			self.url = node.childByName('URL').value

	def __repr__(self):
		return '%s (%s)' % (super(CalendarItem, self).__repr__(), self.__dict__)

class TODOItem(CalendarItem):
	def asRSSDictionary(self):
		# title = None,  # string
		# link = None,   # url as string
		# description = None, # string
		# author = None,      # email address as string
		# categories = None,  # list of string or Category
		# comments = None,  # url as string
		# enclosure = None, # an Enclosure
		# guid = None,    # a unique string
		# pubDate = None, # a datetime
		# source = None,  # a Source
		theTitle = 'TODO: %(summary)s' % self.__dict__
		if self.due != None:
			theTitle += ' (Due %(due)s)' % self.__dict__
		if self.url != None:
			theLink = self.url
		else:
			theLink = 'ical:%(uid)s' % self.__dict__
		theDescription = '%(description)s' % self.__dict__
		theDate = datetime.datetime.utcnow()
		theRSSDictionary = { 'title':theTitle, 'link':theLink, 'description':theDescription, 'guid':self.uid, 'pubDate':theDate }
		return theRSSDictionary

class EventItem(CalendarItem):
	def asRSSDictionary(self):
		theTitle = '%s %s' % (str(self.startDateTime), self.summary)
		if self.url != None:
			theLink = self.url
		else:
			theLink = 'ical:%(uid)s' % self.__dict__
		theDescription = '%(description)s' % self.__dict__
		theDate = datetime.datetime.utcnow()
		theRSSDictionary = { 'title':theTitle, 'link':theLink, 'description':theDescription, 'guid':self.uid, 'pubDate':theDate }
		return theRSSDictionary

class CalendarReader(object):
	def __init__(self):
		super(CalendarReader, self).__init__()
		self.name = None
		self.eventItems = []
		self.todoItems = []

	def read(self, file):
		theReader = MimeDir.MimeDirReader()
		theRootNode = theReader.read(iter(file))

		if theRootNode.childByName('X-WR-CALNAME') != None:
			self.name = theRootNode.childByName('X-WR-CALNAME').value

		for theNode in theRootNode.children:
			if theNode.name == 'VEVENT':
				theEventItem = EventItem()
				theEventItem.setWithMimeDirNode(theNode)
				self.eventItems.append(theEventItem)
			elif theNode.name == 'VTODO':
				theTODOItem = TODOItem()
				theTODOItem.setWithMimeDirNode(theNode)
				self.todoItems.append(theTODOItem)

if __name__ == '__main__':
	theFile = file(os.path.expanduser('~/Library/Calendars/Home.ics'))
	theReader = CalendarReader()
	theReader.read(theFile)
	for theEventItem in theReader.eventItems:
		pprint(theEventItem.asRSSDictionary())
	for theTodoItem in theReader.todoItems:
		pprint(theTodoItem.asRSSDictionary())

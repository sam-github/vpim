#!/usr/bin/python

import iCalendar
import datetime
import PyRSS2Gen
import sys
import urllib2
import os
import glob
import traceback
import re
from pprint import pprint

class iCalToRSS(object):
	def __init__(self):
		super(iCalToRSS, self).__init__

	def processAllLocalCalendarFiles(self):
		theTitle = 'iCal Feed'
		theLink = ''
		theDescription = ''
		# title,
		# link,
		# description,
		# 
		# language = None,
		# copyright = None,
		# managingEditor = None,
		# webMaster = None,
		# pubDate = None,  # a datetime, *in* *GMT*
		# lastBuildDate = None, # a datetime
		# 
		# categories = None, # list of strings or Category
		# generator = _generator_name,
		# docs = "http://blogs.law.harvard.edu/tech/rss",
		# cloud = None,    # a Cloud
		# ttl = None,      # integer number of minutes
		# 
		# image = None,     # an Image
		# rating = None,    # a string; I don't know how it's used
		# textInput = None, # a TextInput
		# skipHours = None, # a SkipHours with a list of integers
		# skipDays = None,  # a SkipDays with a list of strings
		# 
		# items = None,     # list of RSSItems
		self.rss = PyRSS2Gen.RSS2(title = theTitle, link = theLink, description = theDescription, lastBuildDate = datetime.datetime.utcnow())

		self.processAllTigerLocalCalendarFiles()
		self.processAllPantherLocalCalendarFiles()
		theRSSString = self.rss.to_xml()
		sys.stdout.write(theRSSString)

	def processAllTigerLocalCalendarFiles(self):
		for thePath in glob.glob(os.path.expanduser('~/Library/Application Support/iCal/Sources/*')):
			thePath = os.path.join(thePath, 'corestorage.ics')
			theFile = file(thePath)
			theCalendar = iCalendar.CalendarReader()
			theCalendar.read(theFile)
			self.processOneCalendar(theCalendar)
		

	def processAllPantherLocalCalendarFiles(self):
		for thePath in glob.glob(os.path.expanduser('~/Library/Calendars/*.ics')):
			theFile = file(thePath)
			theCalendar = iCalendar.CalendarReader()
			theCalendar.read(theFile)
			self.processOneCalendar(theCalendar)

	def processOneURL(self, url):
		theURLFile = urllib2.urlopen(self.processUrl(url))
		theCalendar = iCalendar.CalendarReader()
		theCalendar.read(theURLFile)

		theTitle = '%(name)s iCal Feed' % theCalendar.__dict__
		theLink = url
		theDescription = 'Feed for %(name)s' % theCalendar.__dict__
		self.rss = PyRSS2Gen.RSS2(title = theTitle, link = theLink, description = theDescription, lastBuildDate = datetime.datetime.utcnow())

		self.processOneCalendar(theCalendar)
		theRSSString = self.rss.to_xml()
		sys.stdout.write(theRSSString)
		
	def processOneCalendar(self, calendar):
		try:
			theRSSItems = []
	
			for theItem in calendar.eventItems + calendar.todoItems:
				theRSSDictionary = theItem.asRSSDictionary()
				theRSSItem = PyRSS2Gen.RSSItem(**theRSSDictionary)
				theRSSItems.append(theRSSItem)
			self.rss.items += theRSSItems
		except Exception, theException:
			theTitle = 'iCalToRSS Error'
			theLink = ''
			theDescription = '''<pre>Could not produce feed for '%s'.\nAn error of type '%s' occured.\nTraceback:\n<pre>%s</pre>''' % (sys.argv[1], theException, '\n'.join(traceback.format_list(traceback.extract_tb(sys.exc_traceback))))
			theRSSItem = PyRSS2Gen.RSSItem(title=theTitle, description=theDescription)
			self.rss.items += theRSSItems
	
	def processUrl(self, url):
		if url[0:len('webcal:')] == 'webcal:':
			url = 'http:' + url[len('webcal:'):]
		elif re.match('[^/]+:.+', url) == None:
			url = 'file://' + os.path.normpath(os.path.expanduser(url))
		return url

def Main(argv):
	if len(argv) == 2:
		theURL = argv[1]
		theThing = iCalToRSS()
		theThing.processOneURL(theURL);
	else:
		iCalToRSS().processAllLocalCalendarFiles()

def Test():
	Main(sys.argv[0:1] + ['~/Desktop/Astronomy.ics'])

if __name__ == '__main__':
	Main(sys.argv)
# 	Test()
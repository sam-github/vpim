#!/usr/bin/env ruby
#############################################################################
#                           COPYRIGHT
#
# Copyright 2002 Thorsten Roggendorf
# Contact schrotie@uni-bielefeld.de
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#############################################################################

#
# A central part of this script - the vcard format definition - was taken
# from a Perlscript that was written by Michael MacDonald at Ximian.
#


$assignstr = "Title,Anrede,Titre\r
First Name,Vorname,Pr�nom\r
Middle Name,Weitere Vornamen,Deuxi�me pr�nom\r
Last Name,Nachname,Nom\r
Suffix\r
PO Box,Postfach\r
Business Street,Stra�e gesch�ftlich,Rue (bureau)\r
Business Street 2,Stra�e gesch�ftlich 2,Rue (bureau) 2\r
Business City,Ort gesch�ftlich,Ville (bureau)\r
Business State,Region gesch�ftlich,D�p/R�gion (bureau)\r
Business Postal Code,Postleitzahl gesch�ftlich,Code postal (bureau)\r
Business Country,Land gesch�ftlich,Pays (bureau)\r
Business Phone,Telefon gesch�ftlich,T�l�phone (bureau)\r
Business Phone 2,Telefon gesch�ftlich 2,T�l�phone 2 (bureau)\r
Business Fax,Fax gesch�ftlich,T�l�copie (bureau)\r
Company Main Phone,Telefon Firma,T�l�phone soci�t�\r
Home Street,Stra�e privat,Rue (domicile)\r
Home Street 2,Stra�e privat 2,Rue (domicile) 2\r
Home City,Ort privat,Ville (domicile)\r
Home State,Region privat,D�p/R�gion (domicile)\r
Home Postal Code,Postleitzahl privat,Code postal (domicile)\r
Home Country,Land privat,Pays (domicile)\r
Home Phone,Telefon privat,T�l�phone (domicile)\r
Home Phone 2,Telefon privat 2,T�l�phone 2 (domicile)\r
Home Fax,Fax privat,T�l�copie (domicile)\r
Other Street,Weitere Stra�e,Rue (autre)\r
Other Street 2,Weitere Stra�e 2,Rue (autre) 2\r
Other City,Weiterer Ort,Ville (autre)\r
Other State,Weitere Region,D�p/R�gion (autre)\r
Other Postal Code,Weitere Postleitzahl,Code Postal (autre)\r
Other Country,Weiteres Land,Pays (autre)\r
Other Phone,Weiteres Telefon,T�l�phone (autre)\r
Other Fax,Weiteres Fax,T�l�copie (autre)\r
Mobile Phone,Mobiltelefon,T�l. mobile\r
Car Phone,Autotelefon\r
Pager\r
Primary Phone,Haupttelefon,T�l�phone principal\r
ISDN,RNIS\r
Callback,R�ckmeldung\r
TTY/TDD Phone,Telefon f�r H�rbehinderte\r
Telex\r
Radio Phone\r
E-mail Address,E-Mail-Adresse,Adresse de messagerie\r
E-mail 2 Address,E-Mail 2: Adresse,Adresse de messagerie 2\r
E-mail 3 Address,E-Mail 3: Adresse,Adresse de messagerie 3\r
Company,Firma,Soci�t� \r
Department,Abteilung\r
Job Title,Position,Titre2\r
Profession,Beruf\r
Assistant\'s Name,Name Assistent,Nom de l\'assistant(e)\r
Assistant\'s Phone,Telefon Assistent,T�l�phone de l\'assistant(e)\r
Spouse,Partner\r
Anniversary,Jahrestag\r
Manager\'s Name,Name des/der Vorgesetzten\r
Office Location,B�ro\r
Birthday,Geburtstag\r
Notes,Notizen\r
Categories,Kategorien,Cat�gories\r
Internet Free Busy,Internet-Frei/Gebucht\r
Web Page,Webseite,Page Web"


$vcardFormat = \
	[
	['FN', 'Title', '', 'First Name', '', 'Middle Name', '', 'Last Name', '', 'Suffix', ''],
	['N', 'Last Name', '', 'Suffix', ';', 'First Name', ';', 'Middle Name', ';', 'Title', ''],
	['ADR;WORK', 'PO Box', ';', 'Business Street 2', ';', 'Business Street', ';', 'Business City', ';', 'Business State', ';', 'Business Postal Code', ';', 'Business Country', ''],
	['LABEL;QUOTED-PRINTABLE;WORK', 'PO Box', '', 'Business Street', '=0A', 'Business Street 2', '=0A', 'Business City', ',', 'Business State', '', 'Business Postal Code', '=0A', 'Business Country', ''],
	['TEL;WORK;VOICE', 'Business Phone'],
	['TEL;WORK;VOICE2', 'Business Phone 2'],
	['TEL;WORK;FAX', 'Business Fax'],
	['TEL;WORK;COMPANY', 'Company Main Phone'],
	['ADR;HOME', '', ';', 'Home Street 2', ';', 'Home Street', ';', 'Home City', ';', 'Home State', ';', 'Home Postal Code', ';', 'Home Country', ''],
	['LABEL;QUOTED-PRINTABLE;HOME', 'Home Street', '=0A', 'Home Street 2',  '=0A', 'Home City', ',', 'Home State', '', 'Home Postal Code', '=0A', 'Home Country', ''],
	['TEL;HOME;VOICE', 'Home Phone'],
	['TEL;HOME;VOICE2', 'Home Phone 2'],
	['TEL;HOME;FAX', 'Home Fax'],
	['ADR;POSTAL', '', ';', 'Other Street 2', ';', 'Other Street', ';', 'Other City', ';', 'Other State', ';', 'Other Postal Code', ';', 'Other Country', ''],
	['LABEL;QUOTED-PRINTABLE;POSTAL', 'Other Street', '=0A', 'Other Street 2', '=0A', 'Other City', ',', 'Other State', '', 'Other Postal Code', '=0A', 'Other Country', ''],
	['TEL;VOICE', 'Other Phone'],
	['TEL;FAX', 'Other Fax'],
	['TEL;CELL', 'Mobile Phone'],
	['TEL;CAR', 'Car Phone'],
	['TEL;PAGER', 'Pager'],
	['TEL;PREF', 'Primary Phone'],
	['TEL;ISDN', 'ISDN'],
	['TEL;X-EVOLUTION-CALLBACK', 'Callback'],
	['TEL;X-EVOLUTION-TTYTDD', 'TTY/TDD Phone'],
	['TEL;X-EVOLUTION-TELEX', 'Telex'],
	['TEL;X-EVOLUTION-RADIO', 'Radio Phone'],
	['EMAIL;INTERNET', 'E-mail Address'],
	['EMAIL;INTERNET2', 'E-mail 2 Address'],
	['EMAIL;INTERNET3', 'E-mail 3 Address'],
	['ORG', 'Company', ';', 'Department', ''],
	['TITLE', 'Job Title'],
	['ROLE', 'Profession'],
	['X-EVOLUTION-ASSISTANT', "Assistant\'s Name"],
	['TEL;X-EVOLUTION-ASSISTANT', "Assistant\'s Phone"],
	['X-EVOLUTION-SPOUSE', 'Spouse'],
	['X-EVOLUTION-ANNIVERSARY', 'Anniversary'],
	['X-EVOLUTION-MANAGER', "Manager\'s Name"],
	['X-EVOLUTION-OFFICE', 'Office Location'],
	['BDAY', 'Birthday'],
	['NOTE', 'Notes'],
	['FBURL', 'Internet Free Busy'],
	['URL', 'Web Page']
	]


$msg = {}
$msg["version"] = \
"	version 0.0.7 of csv2vcard
	Copyright 2002 Thorsten Roggendorf
	This is software is licensed under the GPL
"
$msg["usage"] = \
	"	Usage:
		" + $0 + " without arguments - starts grafical user interface.
			If you pass arguments " + $0 + " will run noninteractively:
		" + $0 + " [--verbose] infile outfile
		" + $0 + " --print-assignment
		" + $0 + " --help
	type \'"  + $0 + " --help\' for more instructions\n"
$msg["help"] = $msg["usage"] + \
"
	This is a ruby script for converting
	comma seperated value (*.csv) files containing
	contact information to the vcard format.

	Assignment file:
		Part of the trick performed by csv2vcard, is to assign data
		from csv files to fields in a vcard. The csv data is defined
		by identifiers in the first line of a csv file. There are as
		many identifier standards as there are programs that export
		csv ... times the languages these programs are translated to.
		Csv2vcard has a standard assignment policy, but that is very,
		very limited as of this writing. To extend its knowledge about
		assignment csv2vcard will try to load ~/.csv2vcard.assignment.
		The easiest way to generate that file yourself is by using
		csv2vcard\'s grafical user interface.
		However, if you won't be bothered to use the gui for some
		reason, you can write an assignment file yourself. The file
		has to be in the csv format, that is parsable byx csv2vcard.
		See http://www.ruby-lang.org/en/raa-list.rhtml?name=csv for
		a specification of that format.
		Then use the -p option (see there) to get a starting point
		for your assignment file.
		Each line contains an assignment. Just append the according
		identifiers from your csv file to each line. Don\'t remove
		the <carriage return><newline> sequence at the end of the
		lines or you'll break the assignment file. Quote your csv
		field identifiers with \"...\" if they contain commas or
		newlines or other weird characters.
		The first entry of each line is the default id. Don\'t change
		it or you\'ll break the file.
		Good luck!

	Options:

	-h, --help
		Display this message

	-v, --verbose
		Optional
		Be verbose. This option gives you more details on
		what information is lost during the translation.

	-p, --print-assignment
		This script has a built in default assignment policy. To
		fascilitate your writing an assignment file you can make the
		script spit out the default assignment file by typing:
		" + $0 + " --print-assignment
		If you want to save that in a file use a pipe:
		" + $0 + " --print-assignment > assignment.txt
		If you manage to extend the assignment policy with this feature,
		please, please mail me that file of yours so I can incorporate it
		to my release of csv2vcard.

	Note:
		If you try to convert a csv file you got from windows or dos
		you\'ll better not convert it with dos2unix before translating it
		with " + $0 + ". You\'ll break the csv file as far as csv2vcard is
		concerned!


	Written and maintained by Thorsten Roggendorf.
	This is GPL software. It\'s free including free of warranties.
	If it eats your data I hope it enjoys the meal at least ;-)
	Type: less \`which " + $0 + "\`
	to read the license at the beginning of this script.

	Bug reports, feature requests, assignment files, praise and flames to:
		schrotie@uni-bielefeld.de

	P.S.:
		This is my first shot at ruby
		so go easy on the flames ;->\n"
$msg["csvmissing"] = \
"

 - csv: this module is required for both gui and command
	line mode to work. Get it at
	http://www.ruby-lang.org/en/raa-list.rhtml?name=csv"
$msg["guimissing"] = \
": this module is required for the grafical user
	interface to work. You don\'t need it if you want
	to run csv2vcard noninteractively in comandline mode.
	On Debian Woody install package "
$msg["gtkmissing"] = \
"

 - gtk" + $msg["guimissing"] + "libgtk-ruby ...
	don\'t know about other distributions.
	You can also get it at
	http://www.ruby-lang.org/en/raa-list.rhtml?name=Ruby%2FGTK"
$msg["glademissing"] = \
"

 - lglade" + $msg["guimissing"] + "libglade-ruby ...
	don\'t know about other distributions.
	You can also get it at
	http://www.ruby-lang.org/en/raa-list.rhtml?name=Ruby%2FLibGlade"
$msg["optmissing"] = \
"

- getoptlong: this module is required for noninteractive command
	line mode only. It should however be included in you
	ruby installation - your ruby installation might be broken
	or dated. Get the latest ruby plus lots of infos on ruby at
	http://www.ruby-lang.org/en/index.html"
$msg["missing"] = \
"
One or more ruby modules are missing, that are required to run csv2vcard.
Please install the following packages and try again:"
$msg["getmodules"] = \
"

You can also find all required modules and much more ruby stuff at
	http://www.ruby-lang.org/en/raa.html"
$msg["installationScrewed"] = \
"I\'m indeed very sorry ... it looks like the installation of csv2vcard is screwed. I did not write the installation script, so I don\'t know, what went wrong.
Here\'s what you can do: go to the directory, where you originally unpacked csv2vcard. You should find a file called fallback.tar.gz. Unpack that file, it will extract to a subdirectory called csv2vcard. You can now run csv2vcard locally from that directory ... I hope you have more luck there ;-) ... more apologies\n"
$msg["open"] = \
"Click on the top left button \"csv file\" to open your csv file.

Csv Format:
The file should have windows style line seperators (<CR><LF> or in escape sequence: \\r\\n ... don\'t worry, you don\'t have to unsderstand this).
Suitable files are exported by most windows programs. Do NOT use the dos2unix command (or something with equal functionality) to convert them!"
$msg["noInFile"] = \
"I have no input, please choose an input file first."
$msg["noMapping"] = \
"I have no suitable assignment for your csv file. Please provide a suitable assignment file or use the gui to generate an assignment."
$msg["oops"] = \
"Oops! That did not work.

Probable reasons: you gave an invalid file name, or the file was not parsable (perhaps it\'s no windows style csv file - either generated by a unix app or you ran dos2unix on it).
Csv2vcard uses an external csv parser library. Please refer to http://www.ruby-lang.org/en/raa-list.rhtml?name=csv for details on the supported format.

Please try again with a valid csv file."
$msg["assign"] = \
"Ok, your file seems to have been successfully parsed. The fields of your csv file should now be displayed in the right list window.

To get a valid assignment you can first try auto assign (middle left button).

If that does not work, you have to assign the fields by hand. Click on one of the lists to mark entries. Then click on the according field on the other list to assign the fields. Assigned fields will be displayed in the left list, and assigned fields from your file will be removed from the right list. If you get something wrong, just assign another field to the wrongly assigned field in the left list. The previously assigned value will reappear at the bottom of the right list.

When your done select an output file by clicking on vCard file (bottom left button - if you don\'t do so the output will be stored under same name as the input file with the additional suffix .vcf). Finally click on convert (top right button) to do the magic."
$msg["assFn"] = ENV["HOME"] + "/.csv2vcard.assignment"
$msg["assFCorrupted"] = \
"The assignment file " + $msg["assFn"] + " is currupted. \n\nPlease run csv2vcard with the -h option to get details on the assignment file format. You probably hand edited that file and introduced some error. Csv2vcard will not work, until that file is fixed or (re)moved."
$msg["assFunreadable"] = \
"The assignment file " + $msg["assFn"] + " exists but you don\'t have the permission to read it. Please fix this problem before trying again"
$msg["assFread"] = $msg["assFn"] + " was successfully read and will be used for automatic assignment."
$msg["defaultAss"] = $msg["assFn"] + " was not found, using only default assignment for automatic assignment."
$msg["sleep"] = 3
$msg["assFunwritable"] = \
"Something went wrong, when I tried to write to " + $msg["assFn"] + ". Possible reasons: You don\'t have permission to write to that file or the harddisk is full. Please fix the problem and try again."
$msg["wroteAssF"] = "Successfully wrote assignment file to " + $msg["assFn"]
$msg["wait"] = "Please wait ... processing."
$msg["dupeIds"] = \
"One or more dupes were found in the field identifiers of your csv file. Thus an unambigous mapping is not possible. You can solve this problem by editing the first line of your csv file to remove the ambiguity. You have to take care though, to keep the file format intact. Many editors under Unix/Linux might automatically save your file in unix format, making it unparsable for csv2vcard. You can either try to le�ve the format intact by using an appropriate editor (glimmer works as far as I know), or by later running unix2dos on the modified file.
The following field identifiers are ambigous:
"
$msg["dupeAss"] = \
"One or more dupes were found in the assignment. This probably means, that your assignment file " + $msg["assFn"] + " contains the ambiguity. Please try to fix that file for csv2vcard to work. The following identifiers were found multiple times:"
$msg["invalidAss"] = $msg["assFn"] + \
" contains one or more invalid assignments. The first entry in each line of an assignment file must be one of the known identifiers sopported by csv2vcard. Call csv2vcard with the -p option to see a valid assignment. Only the first entries displayd there are supported. Please fix that problem before trying again. A list of the invalid identifiers follows:"
$msg["sizes"] = \
"Your csv file does not have an equal number of entries in each line. Thus an unambigues mapping to the vcard format is not possible. It might be a parse problem, but that\'s rather unlikely. If you suspect it to be a parse problem, please refer to http://www.ruby-lang.org/en/raa-list.rhtml?name=csv for details on the format supported by the csv parser that is used by csv2vcard.

More likely your csv file is just corrupted for some reason ...

Details: The first number in the in the following list is the number of fields in the first line of your csv file (the line with the field identifiers). The following numbers identify the erroneous lines in the format linenumber->numberOfFields. You can try to manually fix the problem by hand editing the csv file if you feel confident enough, but take care to retain the csv format - many editors under Unix/Linux might automatically save your file in unix format, making it unparsable for csv2vcard. You can either try to le�ve the format intact by using an appropriate editor (glimmer works as far as I know), or by later running unix2dos on the modified file. Here comes the list of erroneous lines:
"
$msg["success"] = "The translation was finished successfully. No information was lost."
$msg["partialsuccess"] = "The translation was partially succesful. Information was lost."
$msg["nosuccess"] = \
"The translation was unsuccesful. No fields from your csv file could be translated. You should manually assign the fields from your csv file to vcard fields using the lists on the right."
$msg["mail"] = \
"Some or all of your assignments are not yet included in the distribution of csv2vcard. Please take a few seconds to mail your assignment to schrotie@uni-bielefeld.de so that I can include them in the distribution. You can save others some trouble with little effort. Please save your assignment by clicking on save assignemt (bottom right button) and then mail ~/.csv2vcard.assignement to the above adress."
$msg["unfound"] = \
"Some fields from your csv file could not be translated. The lables of these fields are listed below. Only fields which contained information are listed - information was definitly lost."
$msg["dates"] = \
"I could not determine the date (birthday, aniversary) format in your csv file. Thus I did not convert the date format. It should be YYYY-MM-DD. The following list shows the dates in the format I found in your csv file. If the dates, don\'t have the YYYY-MM-DD format, they will be broken. Please report this problem to schrotie@uni-bielefeld.de - I\'ll try to come up with better handling of this problem in a future release. The list is in the format: 

dateType1 of \"firtsName1 lastName1\" is csvDate1, dateType2 of \"firtsName2 lastName2\" is csvDate2 ...

Another list with information of how the translation went is following this list (if anything else went wrong):"
$msg["verbose"] = \
"The following is a detailed list of what information was lost. No more important information is displayed behind this list. The list has the format:

firstName1 lastName1:
csvFieldName1.1 = csvFieldData1.1, csvFieldName1.2 = csvFieldData1.2, ...

firstName2 lastName2:
csvFieldName2.1 = csvFieldData2.1, csvFieldName2.2 = csvFieldData2.2, ...
...

Ok, here we go:"
$msg["cliMail"] = \
"	If you get this program to work with your modified assignment file,
	please take the time to mail your assignment file to
	schrotie@uni-bielefeld.de - I\'ll include it to the next release and
	you\'ll save others the work of repeating your effort."



# Load only required modules
req = ""
begin require "csv"; rescue LoadError; req += $msg["csvmissing"]; end
if $*.empty?
  begin; require 'gtk'; rescue LoadError; req += $msg["gtkmissing"]; end
  begin; require 'lglade'; rescue LoadError; req += $msg["glademissing"]; end
else
  begin; require 'getoptlong'; rescue LoadError; req += $msg["optmissing"]; end
end
unless req.empty?
  print $msg["missing"] + req +  $msg["getmodules"] + "\n\n" + $msg["usage"]
  exit
end



# Classes that do the actual translation from csv to vcard:
class ProgressErrors
  "Data structure to collect information about how the conversion goes"
  def initialize
    @ids, @data, @dates = [], [], []
  end
  def addDate id, dat
    @dates.push [id, dat]
  end
  def nameDates name
    @dates.each {|i| i.push name if i.size == 2}
  end
  def dates
    @dates.collect! {|i| i[0] + " of " + i[2] + " is " + i[1]}
    @dates.join ", "
  end
  def noDates?; return @dates.empty?; end
  attr_accessor :ids, :data
end

class VcardData
  "Small data structure to hold an identifier and the deliminator"
  def initialize data, deliminator
    "Expects two strings as argument (second is optinal):
       the data and the deliminator "
    @data = data
    @deliminator = deliminator
  end
  attr_reader :data, :deliminator
end

class VcardField
  "One field of a vcard"
  private
  def chk key, line, mapping, foundIds
    "Check if we can retrieve the required information from the current line"
    if mapping.key?(key) and line.size > mapping[key] and line[mapping[key]]
      foundIds.push mapping[key]
      return true
    end
    false
  end
  def vcdDate csvDate
    "Convert dates from csv format to vcard format - this will like have to be adjusted for other date formates"
    return nil if csvDate.empty? or (csvDate == "0.0.00") or !csvDate
    date = csvDate.split(".")
    (@pi.addDate @id, csvDate; return csvDate) unless date.size == 3
    2.times {|i| date[i] = (date[i].size < 2) ? ("-0" + date[i]) : ("-" + date[i])}
    return date[2] + date[1] + date[0]
  end
  def add data, deliminator = ""
    "Add date to this vcard entry"
    data = vcdDate data if (@start == "BDAY") or (@start == "X-EVOLUTION-ANNIVERSARY")
    return if data ? data.empty? : true
    if data.index "\n"
      @encoding = true
      data.gsub! "\n", "=0D=0A=\n "
    end
    @data.push VcardData.new(data, deliminator)
  end
  public
  def initialize line, format, mapping, progressInfo, foundIds
    "Expects a line from  a csv file and a vcard field format list plus a mapping and an array to tell what we found"
    @pi = progressInfo
    @start = format[0]
    format = format[1..-1]
    @data = []
    @encoding = nil
    if format.size == 1
      @id = format[0]
      add line[mapping[format[0]]] if chk format[0], line, mapping, foundIds
    else
      foundIt = nil
      0.step((format.size - 1), 2) do |i|
	if chk format[i], line, mapping, foundIds
	  @id = format[i]
	  add line[mapping[format[i]]], format[i + 1]
	  foundIt = true
	else
	  add "", format[i + 1]
	end
	@data = [] unless foundIt
      end
    end
    @start += ";QUOTED-PRINTABLE" if @encoding and @start.index("QUOTED-PRINTABLE") == -1
  end
  def str
    "Convert to string in vcard format"
    tmp = @start + ":"
    @data.each {|i| tmp += " " + i.data + i.deliminator}
    tmp + "\n"
  end
  attr_reader :data
end

class Vcard
  "Vcard object"
  def initialize line, mapping, ids, progressInfo
    "expects a line of a csv file, a mapping, an array where information about failures is stored, an array with the csv field identifiers and another array where we are more verbose about lost information"
    pi = progressInfo
    foundIds = []
    @fields = []
    $vcardFormat.each do |i|
      tmp = VcardField.new line, i.dup, mapping, progressInfo, foundIds
      @fields.push tmp unless tmp.data.size == 0
    end
    name = "\"" \
      + ((mapping.key? "First Name") ? (line[mapping["First Name"]] \
					? line[mapping["First Name"]] : "unknown") : "unknown") + ' ' \
      + ((mapping.key? "Last Name") ? (line[mapping["Last Name"]] \
				       ? line[mapping["Last Name"]] : "unknown") : "unknown")+ "\""
    details = []
    line.size.times do |i|
      if line[i] and (not (foundIds.index i))
	pi.ids.push ids[i] unless pi.ids.index(ids[i])
	details.push "#{ids[i]} = #{line[i]}"
      end
    end
    pi.data.push name + ":\n" + details.join(", ") unless details.empty?
    pi.nameDates name
  end
  def str
    "Convert to string in vcard format"
    tmp = "BEGIN:VCARD\n"
    @fields.each {|i| tmp += i.str}
    tmp + "END:VCARD\n\n"
  end
end

# Methods common to gui and non interactive mode
def csvOk? infn, csvl, ids
  "Parse csv file and check if it is translatable"
  begin
    # parse file
    CSV::Reader.parse( File.open(infn, "r" )) do |i|
      i.collect! {|j| j.isNull = true if j.data.empty?; j}
      csvl.push i.to_a
    end
  rescue
    yield $msg["oops"]
    return false
  end
  ids.concat csvl.shift # first line contains csv identifiers

  # Check if assignment is unambiguis
  chk = []
  ids.each {|a| chk.push a}
  dupes = []
  until chk.size == 0
    dupe = chk.pop
    dupes.push dupe if chk.index dupe
  end
  yield $msg["dupeIds"] + dupes.join(", ") unless dupes.empty?

  # Check if all lines have the same number of entries
  size = ids.size
  sizesOk = true
  lines = [size]
  csvl.size.times do |i|
    err = !(csvl[i].size == size)
    sizesOk = err ? false : sizesOk
    lines.push "#{i + 1}->#{@csvl[i].size}" if err
  end
  yield $msg["sizes"] + lines.join(", ") unless sizesOk
  return dupes.empty? && sizesOk
end

def loadAssignment newAssignment = []
  "Load ~/.csv2vcard.assignment or standard assignment, if the assignment file is not available. Check assignment for ambiguity"
  (yield msg["assFunreadable"]; return) if test(?e, $msg["assFn"]) and not test(?r, $msg["assFn"])
  fAss, dAss, nAss = [], [], newAssignment
  CSV::Reader.parse($assignstr) {|i| dAss.push i.to_a}
  if test(?r, $msg["assFn"])
    # read assignment file
    begin
      CSV::Reader.parse(File.open $msg["assFn"]) {|i| fAss.push i.to_a} 
    rescue
      yield $msg["assFCorrupted"]
      return []
    end

    # check assignment file for dupes
    dupes = []
    flat = fAss.flatten
    flat.each {|i| found = nil; flat.each{|j| dupes.push i if found and i == j; found = true if i == j}}
    (yield $msg["dupeAss"] + "\n\n" + dupes.uniq.join(", "); return []) unless dupes.empty?

    # check if all first entries in each line of the assignment file have valid values:
    invalid = []
    fAss.each do |i|
      found = false
      dAss.each {|j| found = true if i[0] == j[0]}
      invalid.push i[0] unless found
    end
    (yield $msg["invalidAss"] + "\n\n" + invalid.uniq.join(", "); return []) unless invalid.empty?

    # join assignment file and default assignment, assignment file takes precedence
    fAss.each {|fa| fa[1..-1].each {|fid| dAss.each {|dl| dl.delete fid}}} # remove ids from dAss that are also in fAss
    dAss.each {|da| fAss.each {|fa| da.concat fa[1..-1] if (da[0] == fa[0]) and (fa.size > 1)}} # join dAss and fAss
    yield $msg["assFread"]
  else
    yield $msg["defaultAss"]
  end
  # join new assignment and default assignment, new assignment takes precedence
  nAss.each {|na| na[1..-1].each {|fid| dAss.each {|dl| dl.delete fid}}}
  dAss.each {|da| nAss.each {|na| da.concat na[1..-1] if (da[0] == na[0]) and (na.size > 1)}} 
  dAss
end

def autoMap mapping, assignment, ids
  "Automatically guess assignment from known assignment and current csv field identifiers"
  mapp = {}
  ids.size.times {|i| assignment.each {|j| j.each {|k| mapp[j[0]] = i if ids[i] == k}}}
  mapp.each_key {|key| mapping[key] = mapp[key] unless mapping.key? key}
end

def convert fileName, csvl, mapping, assignment, ids, silent = nil
  "Convert csv file to vcard file"
  (yield $msg["noMapping"]; return) if mapping.empty?
  yield $msg["wait"]
  pi = ProgressErrors.new
  outFile = File.open(fileName, 'w')
  csvl.each {|i| outFile.write Vcard.new(i, mapping, ids, pi).str}
  outFile.close

  msg = [pi.ids.empty? ? $msg["success"] : $msg["partialsuccess"]]

  dAss = []
  CSV::Reader.parse($assignstr) {|i| dAss.push i.to_a}
  newAss = false
  assignment.each do |ass|
    1.upto (ass.size - 1) do |i|
      found = false
      dAss.each {|dass| 1.upto (dass.size - 1) {|j| found = (ass[i] == dass[j]) ? true : found}}
      newAss = found ? newAss : true
    end
  end
  msg.concat [$msg["mail"]] if newAss
  msg.concat [$msg["unfound"], pi.ids.join(", ")] unless pi.ids.empty?
  msg.concat [$msg["dates"], pi.dates] unless pi.noDates?
  msg.concat [$msg["verbose"], pi.data.join("\n\n")] unless pi.data.empty? or silent
  yield msg.join("\n\n")
end


# Class that handles interactive mode:
class Gui
  "This class manages the grafical user interface"
  def initialize
    "Constructor uses reset to initialize most stuff"
    begin
      @glade = GladeXML.new("csv2vcard.glade") { |handler| method (handler)}
    rescue
      print $msg["installationScrewed"]
      exit
    end
    @targets = @glade.getWidget "vCard"
    @sources = @glade.getWidget "unassigned"
    @msg = []
    message $msg["version"] + "\n\n" + $msg["open"]
    reset
  end

  def on_exit widget, data, *rest
    "Quit the program"
    Gtk.main_quit
  end

  def message msg
    "Print a message to the main message widget"
    msgW = @glade.getWidget("message")
    @msg[1], @msg[0] = @msg[0], msg
    @glade.getWidget("message").text = msg
    Gtk.main_iteration while Gtk.events_pending
  end

  def reset
    "Revert to start configuration, leaving only the last issued message in untouched"
    @outfn = nil
    @fselect = nil
    @vcardKey = nil
    @csvKey = nil
    @mapping = {}
    @reverseMap = {}
    @ids = []
    @csvl = []
    @sources.each {|i| @sources.remove i}
    @targets.each {|i| @targets.remove i}
    @assignment = loadAssignment {|msg| message msg}
    message @msg[0] + "\n\n" + @msg[1] unless @assignment.empty?
    @assignment.each {|i| @targets.add Gtk::ListItem.new i[0]}
    @targets.show_all

    @glade.getWidget("unassLable").text = "unassigned from\nyour file"
  end

  # Methods for opening, parsing and checking files
 def on_outfile widget, data
   "Outfile button handle"
   file_select("vCard (output)") {|handle| @outfn = handle.get_toplevel.get_filename}
  end
  def on_infile widget, data
    "Infile button handle, opens, parses and checks infile and adjust displayed information"
    file_select("csv (input)") do |handle|
      @fselect.window.lower
      message $msg["wait"]
      @infn = handle.get_toplevel.get_filename
      reset
      if csvOk?(@infn, @csvl, @ids) {|msg| message msg}
	@ids.each {|i| @sources.add Gtk::ListItem.new i}
	@sources.show_all
	@glade.getWidget("unassLable").text = "unassigned from\n#{@infn.split("/")[-1]}"
	message $msg["assign"]
      end
    end
  end
  def file_select ftype
    "Pop up file selection dialog - used by in- and outfile handles"
    unless @fselect
      @fselect = Gtk::FileSelection.new "Select #{ftype} file"
      @fselect.ok_button.signal_connect("clicked") {|handle| yield handle; file_cancel handle}
      @fselect.cancel_button.signal_connect("clicked") {|handle| file_cancel handle}
      @fselect.show_all
    end
  end
  def file_cancel widget
    "Cancel file selection handle"
    widget.get_toplevel.destroy
    @fselect = nil
  end

  # Methods for user defined assignment (that's the soul of the gui)
  def map key, val
    "Map csv field to vcard field, manage internal representations and displayd information"
    if @reverseMap.key? val
      @sources.add Gtk::ListItem.new @reverseMap[val]
      @mapping.delete @reverseMap[val]
      @reverseMap.delete val
    end
    @sources.remove @sources.selection[0]
    @sources.show_all
    @targets.selection[0].child.text = @targets.selection[0].child.text.split(" <- ")[0] + " <- " + key
    @mapping[key] = val
    @reverseMap[val] = key
    @targets.unselect_child @targets.selection[0]
    @vcardKey = nil
    @csvKey = nil
  end
  def on_vCard_select widget, item, whatever
    "Select vcard field handle"
    vkey = item.child.text.split(" <- ")[0]
    @csvKey ? (map @csvKey, vkey) :  (@vcardKey = vkey)
  end
  def on_unassigned_select widget, item, whatever
    "Select csv field handle"
    ckey = item.child.text
    @vcardKey ? (map ckey, @vcardKey) : (@csvKey = ckey)
  end
  def on_vCard_unselect widget, item, whatever
    "Unselect vcard field handle"
    @vcardKey = nil
  end
  def on_unassigned_unselect widget, item, whatever
    "Unselect csv field handle"
    ckey = item.child.text
    @csvKey = nil
  end

  # Methods for remaining gui functionality - convert csv2vcard, display autoassignment and save user defined assignments

  def assign
    @assignment = @reverseMap.to_a
    @assignment = loadAssignment(@assignment) {|msg| message msg}
    message @msg[0] + "\n\n" + @msg[1] unless @assignment.empty?
  end

  def on_convert widget, data
    "Convert csv2vcard - first add known assignments to the user assignments"
    (message $msg["noInFile"]; return) unless @infn
    mapping = {}
    @reverseMap.each_key {|key| mapping[key] = @ids.index @reverseMap[key]}
    assign
    autoMap mapping, @assignment, @ids
    convert((@outfn ? @outfn : (@infn + ".vcf")), @csvl, mapping, @assignment, @ids) {|msg| message msg}
  end

  def on_autoassign
    "Use auto assignment and update the lists visible to the user"
    (message $msg["noInFile"]; return) unless @infn
    mapping = {}
    autoMap mapping, @assignment, @ids
    mapping.each_key do |key|
      @sources.each {|i| @sources.select_child i if @ids[mapping[key]] == i.child.text} 
      @targets.each {|i| @targets.select_child i if key == i.child.text} 
    end
  end

  def on_saveAssign
    assignment = @reverseMap.to_a
    begin
      File.open($msg["assFn"], "w") do |file|
	assignment.collect! {|i| i.join "\",\""}
	assignment.collect! {|i| "\"" + i + "\""}
	file.print(assignment.join "\r\n")
      end
    rescue
      message $msg["assFunwritable"]
      return
    end
    message $msg["wroteAssF"] + "\n\n" + @msg[0]
  end
end

# This class handles the comand line mode
class Cli
  def initialize
    print $msg["version"]
    parseCmdLine
    assignment = loadAssignment {|msg| print "\n\n" + msg + "\n"}
    csvl, ids, mapping = [], [], {}
    csvOk?(@inf, csvl, ids) {|msg| print "\n" + msg; exit}
    autoMap mapping, assignment, ids
    convert(@outf, csvl, mapping, assignment, ids, !@verbose) {|msg| print "\n" + msg + "\n"}
  end
  def parseCmdLine
    "Parse the cmd line arguments and take appropriate actions"
    opts = GetoptLong.new([ "--verbose",          "-v", GetoptLong::NO_ARGUMENT ],
			  [ "--help",             "-h", GetoptLong::NO_ARGUMENT ],
			  [ "--print-assignment", "-p", GetoptLong::NO_ARGUMENT ]
			  )
    verbose = enclosing = assignf = inf = outf = nil
    opts.each do |opt, arg|
      case opt
      when "--help"
        print $msg["help"]
	exit
      when "--print-assignment"
        print $assignstr
        $stderr << $msg["cliMail"]
        exit
      when "--verbose"
        @verbose = true
      end
    end
    usage unless ARGV.size == 2
    @inf = ARGV[0]
    @outf = ARGV[1]
  end
end

# Finally start the program
if $*.empty?
  Gui.new
  Gtk.main
else
  Cli.new
end
